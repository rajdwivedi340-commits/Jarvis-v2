# Jarvis v2 (Personal AI Assistant)
This is a personal Jarvis-like AI for Master Surya.

## 🚀 Setup Guide
1. Clone repo or upload to GitHub.
2. Add your **OpenAI API Key** in environment variables: `OPENAI_API_KEY`.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run locally:
   ```bash
   python server.py
   ```
5. Deploy on **Render** or **Vercel**.

## 🌐 Features
- Frontend + Backend included
- Asks questions & gets AI answers
- Secure API key handling
